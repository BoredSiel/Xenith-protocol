# Hardware

This folder contains files related to hardware.