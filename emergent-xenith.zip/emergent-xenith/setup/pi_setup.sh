#!/bin/bash

echo "=== Xenith Raspberry Pi Setup Script ==="

# Update and upgrade
sudo apt update && sudo apt upgrade -y

# Install Python3, pip, and essential libraries
sudo apt install -y python3 python3-pip python3-dev \
  python3-venv libatlas-base-dev espeak ffmpeg

# Install TTS, Speech Recognition, OpenAI tools
pip3 install --upgrade pip
pip3 install speechrecognition openai gtts pyaudio

# Enable camera and mic (for legacy Raspbian-style systems)
sudo raspi-config nonint do_camera 0

echo "=== Setup Complete. Reboot Recommended. ==="
