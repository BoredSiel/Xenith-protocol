import speech_recognition as sr
import openai
from gtts import gTTS
import os

openai.api_key = "YOUR_API_KEY"

def recognize_speech():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Speak:")
        audio = recognizer.listen(source)
        try:
            return recognizer.recognize_google(audio)
        except sr.UnknownValueError:
            return "Sorry, I didn’t catch that."
        except sr.RequestError:
            return "Speech service is unavailable."

def ask_openai(question):
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": question}]
    )
    return response['choices'][0]['message']['content']

def speak(text):
    tts = gTTS(text=text, lang='en')
    tts.save("response.mp3")
    os.system("mpg123 response.mp3")

if __name__ == "__main__":
    user_input = recognize_speech()
    print("You said:", user_input)
    ai_response = ask_openai(user_input)
    print("AI:", ai_response)
    speak(ai_response)
